class EnhancedProductivityApp {
  constructor() {
    this.api = {
      tasks: "/api/tasks",
      goals: "/api/goals",
      habits: "/api/habits",
      journal: "/api/journal",
    };
    this.state = { section: "dashboard", edit: null, formType: null, mood: "" };
    this.refs = this._bindRefs();
    this._bindNav();
    this._bindGlobal();
    this._initDate();
    this.refreshAll();
  }

  _bindRefs() {
    return {
      sections: document.querySelectorAll(".section"),
      menuLinks: document.querySelectorAll(".menu-link"),
      pageTitle: document.getElementById("pageTitle"),
      currentDate: document.getElementById("currentDate"),
      slideover: document.getElementById("slideover"),
      slideoverTitle: document.getElementById("slideoverTitle"),
      slideoverPanel: document.querySelector(".slideover-panel"),
      formRoot: document.getElementById("dynamicForm"),
      saveForm: document.getElementById("saveForm"),
      cancelForm: document.getElementById("cancelForm"),
      closeSlideover: document.getElementById("closeSlideover"),
      toast: document.getElementById("toast"),
      tasksContainer: document.getElementById("tasksContainer"),
      goalsContainer: document.getElementById("goalsContainer"),
      habitsContainer: document.getElementById("habitsContainer"),
      journalForm: document.getElementById("journalForm"),
      journalDate: document.getElementById("journalDate"),
      journalText: document.getElementById("journalText"),
      journalHistory: document.getElementById("journalHistory"),
    };
  }

  _bindNav() {
    this.refs.menuLinks.forEach(btn => {
      btn.addEventListener("click", () => this.switchSection(btn.dataset.section, btn));
    });
  }

  _bindGlobal() {
    // Global "Add" opens based on current section
    document.getElementById("globalAddBtn").addEventListener("click", () => {
      const type = this.state.section === "tasks" ? "task" :
                   this.state.section === "goals" ? "goal" :
                   this.state.section === "habits" ? "habit" :
                   this.state.section === "journal" ? "journal" : "task";
      this.openForm(type);
    });

    document.querySelectorAll("[data-open]").forEach(b => {
      b.addEventListener("click", () => this.openForm(b.dataset.open));
    });

    this.refs.cancelForm.addEventListener("click", (e) => {
      e.preventDefault(); this.closeSlideover();
    });
    this.refs.closeSlideover.addEventListener("click", () => this.closeSlideover());
    this.refs.saveForm.addEventListener("click", (e) => this.onSave(e));

    // Journal
    this.refs.journalForm.addEventListener("submit", (e) => this.saveJournal(e));
    document.querySelectorAll(".mood").forEach(btn => {
      btn.addEventListener("click", () => {
        this.state.mood = btn.dataset.mood;
        this.toast(`Mood set: ${this.state.mood}`);
      });
    });

    // Timer
    this._bindTimer();
  }

  _bindTimer() {
    let duration = 25 * 60;
    let remaining = duration;
    let interval = null;
    const display = document.getElementById("timerDisplay");
    const render = () => {
      const m = String(Math.floor(remaining / 60)).padStart(2, "0");
      const s = String(Math.floor(remaining % 60)).padStart(2, "0");
      display.textContent = `${m}:${s}`;
    };
    render();

    document.getElementById("startTimer").addEventListener("click", () => {
      if (interval) return;
      interval = setInterval(() => {
        remaining = Math.max(remaining - 1, 0);
        render();
        if (remaining === 0) { clearInterval(interval); interval = null; this.toast("⏰ Time's up!"); }
      }, 1000);
    });
    document.getElementById("pauseTimer").addEventListener("click", () => {
      if (interval) { clearInterval(interval); interval = null; }
    });
    document.getElementById("resetTimer").addEventListener("click", () => {
      if (interval) { clearInterval(interval); interval = null; }
      remaining = duration; render();
    });
    document.querySelectorAll(".preset").forEach(p => {
      p.addEventListener("click", () => {
        if (interval) { clearInterval(interval); interval = null; }
        duration = parseInt(p.dataset.min, 10) * 60;
        remaining = duration; render();
      });
    });
  }

  _initDate() {
    const now = new Date();
    const fmt = now.toLocaleDateString(undefined, { weekday:"long", month:"long", day:"numeric", year:"numeric" });
    this.refs.currentDate.textContent = fmt;
    this.refs.journalDate.valueAsDate = now;
  }

  switchSection(id, btn) {
    this.state.section = id;
    this.refs.sections.forEach(s => s.classList.remove("active"));
    document.getElementById(id).classList.add("active");
    this.refs.menuLinks.forEach(m => m.classList.remove("active"));
    btn.classList.add("active");
    this.refs.pageTitle.textContent = id[0].toUpperCase() + id.slice(1);
  }

  // ---------- Slide-over forms ----------
  openForm(type, data=null) {
    this.state.formType = type;
    this.state.edit = data ? data.id : null;
    this.refs.slideoverTitle.textContent = (data ? "Edit " : "Add ") + (type.charAt(0).toUpperCase()+type.slice(1));
    this.refs.formRoot.innerHTML = this._formHtml(type, data);
    this.openSlideover();
  }

  _formHtml(type, d) {
    d = d || {};
    const text = (v) => (v ?? "");
    const dateVal = (v) => v ? new Date(v).toISOString().slice(0,10) : "";
    if (type === "task") {
      return `
        <label>Title<input class="input" name="title" required value="${text(d.title)}"/></label>
        <label>Description<textarea class="input" name="description">${text(d.description)}</textarea></label>
        <div class="row gap">
          <label style="flex:1">Category
            <select class="input" name="category">
              <option value="">(none)</option>
              <option ${d.category==='work'?'selected':''} value="work">Work</option>
              <option ${d.category==='personal'?'selected':''} value="personal">Personal</option>
              <option ${d.category==='health'?'selected':''} value="health">Health</option>
              <option ${d.category==='learning'?'selected':''} value="learning">Learning</option>
            </select>
          </label>
          <label style="flex:1">Priority
            <select class="input" name="priority">
              <option value="">(none)</option>
              <option ${d.priority==='Critical'?'selected':''} value="Critical">Critical</option>
              <option ${d.priority==='High'?'selected':''} value="High">High</option>
              <option ${d.priority==='Medium'?'selected':''} value="Medium">Medium</option>
              <option ${d.priority==='Low'?'selected':''} value="Low">Low</option>
            </select>
          </label>
        </div>
        <div class="row gap">
          <label style="flex:1">Due Date<input class="input" type="date" name="due_date" value="${dateVal(d.due_date)}"/></label>
          <label style="flex:1">Estimated Time<input class="input" name="estimated_time" value="${text(d.estimated_time)}" placeholder="e.g., 2h"/></label>
        </div>
        <label>Tags<input class="input" name="tags" value="${text(d.tags)}"/></label>
        <label>Status
          <select class="input" name="status">
            <option ${d.status==='pending'?'selected':''} value="pending">Pending</option>
            <option ${d.status==='completed'?'selected':''} value="completed">Completed</option>
          </select>
        </label>
      `;
    }
    if (type === "goal") {
      return `
        <label>Title<input class="input" name="title" required value="${text(d.title)}"/></label>
        <label>Description<textarea class="input" name="description">${text(d.description)}</textarea></label>
        <div class="row gap">
          <label style="flex:1">Category
            <select class="input" name="category">
              <option value="">(none)</option>
              <option ${d.category==='career'?'selected':''} value="career">Career</option>
              <option ${d.category==='health'?'selected':''} value="health">Health</option>
              <option ${d.category==='personal'?'selected':''} value="personal">Personal</option>
              <option ${d.category==='financial'?'selected':''} value="financial">Financial</option>
              <option ${d.category==='relationships'?'selected':''} value="relationships">Relationships</option>
            </select>
          </label>
          <label style="flex:1">Priority
            <select class="input" name="priority">
              <option value="">(none)</option>
              <option ${d.priority==='Critical'?'selected':''} value="Critical">Critical</option>
              <option ${d.priority==='High'?'selected':''} value="High">High</option>
              <option ${d.priority==='Medium'?'selected':''} value="Medium">Medium</option>
              <option ${d.priority==='Low'?'selected':''} value="Low">Low</option>
            </select>
          </label>
        </div>
        <label>Target Date<input class="input" type="date" name="target_date" value="${dateVal(d.target_date)}"/></label>
        <label>Success Metrics<textarea class="input" name="success_metrics">${text(d.success_metrics)}</textarea></label>
        <label>Status
          <select class="input" name="status">
            <option ${d.status==='active'?'selected':''} value="active">Active</option>
            <option ${d.status==='paused'?'selected':''} value="paused">Paused</option>
            <option ${d.status==='completed'?'selected':''} value="completed">Completed</option>
          </select>
        </label>
      `;
    }
    if (type === "habit") {
      return `
        <label>Name<input class="input" name="name" required value="${text(d.name)}"/></label>
        <label>Description<textarea class="input" name="description">${text(d.description)}</textarea></label>
        <div class="row gap">
          <label style="flex:1">Frequency
            <select class="input" name="frequency">
              <option value="">(none)</option>
              <option ${d.frequency==='daily'?'selected':''} value="daily">Daily</option>
              <option ${d.frequency==='weekly'?'selected':''} value="weekly">Weekly</option>
              <option ${d.frequency==='weekdays'?'selected':''} value="weekdays">Weekdays</option>
              <option ${d.frequency==='weekends'?'selected':''} value="weekends">Weekends</option>
            </select>
          </label>
          <label style="flex:1">Difficulty
            <select class="input" name="difficulty">
              <option ${d.difficulty==='easy'?'selected':''} value="easy">Easy</option>
              <option ${d.difficulty==='medium'?'selected':''} value="medium">Medium</option>
              <option ${d.difficulty==='hard'?'selected':''} value="hard">Hard</option>
            </select>
          </label>
        </div>
        <label>Preferred Time
          <select class="input" name="preferred_time">
            <option value="">Any</option>
            <option ${d.preferred_time==='morning'?'selected':''} value="morning">Morning</option>
            <option ${d.preferred_time==='midday'?'selected':''} value="midday">Midday</option>
            <option ${d.preferred_time==='evening'?'selected':''} value="evening">Evening</option>
            <option ${d.preferred_time==='night'?'selected':''} value="night">Night</option>
          </select>
        </label>
        <label>Status
          <select class="input" name="status">
            <option ${d.status==='active'?'selected':''} value="active">Active</option>
            <option ${d.status==='paused'?'selected':''} value="paused">Paused</option>
          </select>
        </label>
      `;
    }
    if (type === "journal") {
      const today = new Date().toISOString().slice(0,10);
      return `
        <label>Date<input class="input" type="date" name="date" value="${dateVal(d.date) || today}"/></label>
        <label>Mood
          <select class="input" name="mood">
            <option ${d.mood==='😊'?'selected':''} value="😊">😊</option>
            <option ${d.mood==='😐'?'selected':''} value="😐">😐</option>
            <option ${d.mood==='😢'?'selected':''} value="😢">😢</option>
            <option ${d.mood==='😡'?'selected':''} value="😡">😡</option>
            <option ${d.mood==='🤔'?'selected':''} value="🤔">🤔</option>
          </select>
        </label>
        <label>Text<textarea class="input" name="text">${text(d.text)}</textarea></label>
      `;
    }
    return "";
  }

  openSlideover() {
    this.refs.slideover.classList.add("active");
    document.body.style.overflow = "hidden";
  }
  closeSlideover() {
    this.refs.slideover.classList.remove("active");
    document.body.style.overflow = "";
    this.state.edit = null; this.state.formType = null;
  }

  async onSave(e) {
    e.preventDefault();
    const form = new FormData(this.refs.formRoot);
    const obj = Object.fromEntries([...form.entries()]);
    // normalize dates to yyyy-mm-dd; backend converts to ISO
    if (obj.due_date === "") delete obj.due_date;
    if (obj.target_date === "") delete obj.target_date;
    if (obj.date === "") delete obj.date;

    const type = this.state.formType;
    const base = this.api[type + (type.endsWith("s") ? "" : "s")] || this.api[type + "s"];
    const url = this.state.edit ? `${base}/${this.state.edit}` : base;
    const method = this.state.edit ? "PUT" : "POST";
    const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(obj) });
    if (!res.ok) { this.toast("Save failed"); return; }
    this.toast(this.state.edit ? "Updated!" : "Created!");
    this.closeSlideover();
    this.refreshAll();
  }

  async refreshAll() {
    await Promise.all([this.loadTasks(), this.loadGoals(), this.loadHabits(), this.loadJournal()]);
  }

  // ---------- Render helpers ----------
  _actionBtns(type, item) {
    return `
      <div class="row gap">
        <button class="btn btn-secondary" data-edit="${type}:${item.id}">Edit</button>
        <button class="btn btn-outline" data-del="${type}:${item.id}">Delete</button>
      </div>
    `;
  }

  // ---------- Tasks ----------
  async loadTasks() {
    const res = await fetch(this.api.tasks);
    const data = await res.json();
    this.refs.tasksContainer.innerHTML = data.map(t => `
      <div class="card">
        <div class="row between center">
          <strong>${t.title}</strong>
          <span>${t.priority || ""}</span>
        </div>
        <div>${t.description || ""}</div>
        <small>${t.due_date ? new Date(t.due_date).toLocaleDateString() : ""}</small>
        ${this._actionBtns("task", t)}
      </div>
    `).join("");
    this.refs.tasksContainer.querySelectorAll("[data-edit]").forEach(btn => {
      const [type,id]=btn.dataset.edit.split(":");
      btn.addEventListener("click", async () => {
        const item = await (await fetch(`${this.api.tasks}/${id}`)).json();
        this.openForm(type, item);
      });
    });
    this.refs.tasksContainer.querySelectorAll("[data-del]").forEach(btn => {
      const id = btn.dataset.del.split(":")[1];
      btn.addEventListener("click", async () => {
        if (!confirm("Delete task?")) return;
        await fetch(`${this.api.tasks}/${id}`, { method: "DELETE" });
        this.loadTasks();
      });
    });
  }

  // ---------- Goals ----------
  async loadGoals() {
    const res = await fetch(this.api.goals);
    const data = await res.json();
    this.refs.goalsContainer.innerHTML = data.map(g => `
      <div class="card">
        <div class="row between center">
          <strong>${g.title}</strong>
          <span>${g.priority || ""}</span>
        </div>
        <div>${g.description || ""}</div>
        <small>${g.target_date ? new Date(g.target_date).toLocaleDateString() : ""}</small>
        ${this._actionBtns("goal", g)}
      </div>
    `).join("");
    this.refs.goalsContainer.querySelectorAll("[data-edit]").forEach(btn => {
      const [type,id]=btn.dataset.edit.split(":");
      btn.addEventListener("click", async () => {
        const item = (await (await fetch(`${this.api.goals}/${id}`)).json());
        this.openForm(type, item);
      });
    });
    this.refs.goalsContainer.querySelectorAll("[data-del]").forEach(btn => {
      const id = btn.dataset.del.split(":")[1];
      btn.addEventListener("click", async () => {
        if (!confirm("Delete goal?")) return;
        await fetch(`${this.api.goals}/${id}`, { method: "DELETE" });
        this.loadGoals();
      });
    });
  }

  // ---------- Habits ----------
  async loadHabits() {
    const res = await fetch(this.api.habits);
    const data = await res.json();
    this.refs.habitsContainer.innerHTML = data.map(h => `
      <div class="card">
        <div class="row between center">
          <strong>${h.name}</strong>
          <span>${h.frequency || ""}</span>
        </div>
        <div>${h.description || ""}</div>
        ${this._actionBtns("habit", h)}
      </div>
    `).join("");
    this.refs.habitsContainer.querySelectorAll("[data-edit]").forEach(btn => {
      const [type,id]=btn.dataset.edit.split(":");
      btn.addEventListener("click", async () => {
        const item = (await (await fetch(`${this.api.habits}/${id}`)).json());
        this.openForm(type, item);
      });
    });
    this.refs.habitsContainer.querySelectorAll("[data-del]").forEach(btn => {
      const id = btn.dataset.del.split(":")[1];
      btn.addEventListener("click", async () => {
        if (!confirm("Delete habit?")) return;
        await fetch(`${this.api.habits}/${id}`, { method: "DELETE" });
        this.loadHabits();
      });
    });
  }

  // ---------- Journal ----------
  async saveJournal(e) {
    e.preventDefault();
    const body = {
      date: this.refs.journalDate.value,
      mood: this.state.mood,
      text: this.refs.journalText.value
    };
    const res = await fetch(this.api.journal, { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify(body) });
    if (res.ok) {
      this.refs.journalText.value = "";
      this.state.mood = "";
      this.toast("Journal saved");
      this.loadJournal();
    } else {
      this.toast("Failed to save journal");
    }
  }

  async loadJournal() {
    const res = await fetch(this.api.journal);
    const data = await res.json();
    this.refs.journalHistory.innerHTML = data.map(j => `
      <div class="card">
        <div class="row between center">
          <strong>${new Date(j.date).toLocaleDateString()}</strong>
          <span>${j.mood || ""}</span>
        </div>
        <div>${(j.text||"").replace(/\n/g,"<br>")}</div>
        <div class="row gap" style="margin-top:8px">
          <button class="btn btn-secondary" data-edit="journal:${j.id}">Edit</button>
          <button class="btn btn-outline" data-del="journal:${j.id}">Delete</button>
        </div>
      </div>
    `).join("");
    this.refs.journalHistory.querySelectorAll("[data-edit]").forEach(btn => {
      const [type,id]=btn.dataset.edit.split(":");
      btn.addEventListener("click", async () => {
        const items = await (await fetch(`${this.api.journal}`)).json();
        const item = items.find(x => String(x.id)===String(id));
        this.openForm(type, item);
      });
    });
    this.refs.journalHistory.querySelectorAll("[data-del]").forEach(btn => {
      const id = btn.dataset.del.split(":")[1];
      btn.addEventListener("click", async () => {
        if (!confirm("Delete entry?")) return;
        await fetch(`${this.api.journal}/${id}`, { method:"DELETE" });
        this.loadJournal();
      });
    });
  }

  // ---------- Utils ----------
  toast(msg) {
    this.refs.toast.textContent = msg;
    this.refs.toast.classList.add("show");
    setTimeout(()=>this.refs.toast.classList.remove("show"), 1600);
  }
}

document.addEventListener("DOMContentLoaded", () => {
  window.app = new EnhancedProductivityApp();
});
