import sqlite3 from "sqlite3";
import path from "path";
import { fileURLToPath } from "url";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const dbPath = path.join(__dirname, "data.sqlite");
export const db = new sqlite3.Database(dbPath);

export const initDb = () => new Promise((resolve, reject) => {
  db.serialize(() => {
    db.run("PRAGMA foreign_keys = ON;");
    db.run(`CREATE TABLE IF NOT EXISTS tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT,
      category TEXT,
      priority TEXT,
      due_date TEXT, -- ISO-8601 TEXT
      estimated_time TEXT,
      goal_id INTEGER,
      tags TEXT,
      status TEXT DEFAULT 'pending',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    )`);
    db.run(`CREATE TABLE IF NOT EXISTS goals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT,
      category TEXT,
      priority TEXT,
      target_date TEXT, -- ISO-8601 TEXT
      success_metrics TEXT,
      status TEXT DEFAULT 'active',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    )`);
    db.run(`CREATE TABLE IF NOT EXISTS habits (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      description TEXT,
      frequency TEXT,
      difficulty TEXT,
      preferred_time TEXT,
      status TEXT DEFAULT 'active',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    )`);
    db.run(`CREATE TABLE IF NOT EXISTS journal (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      mood TEXT,
      text TEXT,
      date TEXT NOT NULL, -- ISO-8601 TEXT
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    )`, (err) => {
      if (err) reject(err); else resolve();
    });
  });
});
