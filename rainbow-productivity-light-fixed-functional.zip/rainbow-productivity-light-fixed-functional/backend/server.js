import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import { db, initDb } from "./sqlite.js";


const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Serve frontend
app.use(express.static(path.join(__dirname, "../frontend")));

// Health
app.get("/api/health", (_req, res) => res.json({ ok: true }));

// Helper to run DB statements returning promise
const run = (sql, params=[]) => {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function(err) {
      if (err) reject(err);
      else resolve({ id: this.lastID, changes: this.changes });
    });
  });
};

const all = (sql, params=[]) => {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });
};

const get = (sql, params=[]) => {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
};

// Normalize dates: store as ISO-8601 TEXT to avoid driver type issues
const iso = (v) => (v ? new Date(v).toISOString() : null);

// ------------- TASKS -------------
app.get("/api/tasks", async (_req, res) => {
  try {
    const rows = await all(`SELECT * FROM tasks ORDER BY created_at DESC`);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get("/api/tasks/:id", async (req, res) => {
  try {
    const row = await get(`SELECT * FROM tasks WHERE id=?`, [req.params.id]);
    if (!row) return res.status(404).json({ error: "Not found" });
    res.json(row);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post("/api/tasks", async (req, res) => {
  try {
    const {
      title, description, category, priority, due_date,
      estimated_time, goal_id, tags, status
    } = req.body;

    if (!title) return res.status(400).json({ error: "title required" });

    const now = new Date().toISOString();
    const result = await run(
      `INSERT INTO tasks
       (title, description, category, priority, due_date, estimated_time, goal_id, tags, status, created_at, updated_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
       [title || "", description || "", category || "", priority || "",
        iso(due_date), estimated_time || "", goal_id || null, tags || "",
        status || "pending", now, now]
    );
    const row = await get(`SELECT * FROM tasks WHERE id=?`, [result.id]);
    res.status(201).json(row);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put("/api/tasks/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const prev = await get(`SELECT * FROM tasks WHERE id=?`, [id]);
    if (!prev) return res.status(404).json({ error: "Not found" });

    const patch = {
      title: req.body.title ?? prev.title,
      description: req.body.description ?? prev.description,
      category: req.body.category ?? prev.category,
      priority: req.body.priority ?? prev.priority,
      due_date: req.body.due_date !== undefined ? iso(req.body.due_date) : prev.due_date,
      estimated_time: req.body.estimated_time ?? prev.estimated_time,
      goal_id: req.body.goal_id ?? prev.goal_id,
      tags: req.body.tags ?? prev.tags,
      status: req.body.status ?? prev.status,
      updated_at: new Date().toISOString()
    };

    await run(
      `UPDATE tasks SET
         title=?, description=?, category=?, priority=?, due_date=?,
         estimated_time=?, goal_id=?, tags=?, status=?, updated_at=?
       WHERE id=?`,
       [patch.title, patch.description, patch.category, patch.priority,
        patch.due_date, patch.estimated_time, patch.goal_id, patch.tags,
        patch.status, patch.updated_at, id]
    );
    const row = await get(`SELECT * FROM tasks WHERE id=?`, [id]);
    res.json(row);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete("/api/tasks/:id", async (req, res) => {
  try {
    const result = await run(`DELETE FROM tasks WHERE id=?`, [req.params.id]);
    res.json({ deleted: result.changes > 0 });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ------------- GOALS -------------
app.get("/api/goals", async (_req, res) => {
  try { res.json(await all(`SELECT * FROM goals ORDER BY created_at DESC`)); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

app.post("/api/goals", async (req, res) => {
  try {
    const { title, description, category, priority, target_date, success_metrics, status } = req.body;
    if (!title) return res.status(400).json({ error: "title required" });
    const now = new Date().toISOString();
    const result = await run(
      `INSERT INTO goals
       (title, description, category, priority, target_date, success_metrics, status, created_at, updated_at)
       VALUES (?,?,?,?,?,?,?,?,?)`,
       [title || "", description || "", category || "", priority || "",
        iso(target_date), success_metrics || "", status || "active", now, now]
    );
    const row = await get(`SELECT * FROM goals WHERE id=?`, [result.id]);
    res.status(201).json(row);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put("/api/goals/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const prev = await get(`SELECT * FROM goals WHERE id=?`, [id]);
    if (!prev) return res.status(404).json({ error: "Not found" });

    const patch = {
      title: req.body.title ?? prev.title,
      description: req.body.description ?? prev.description,
      category: req.body.category ?? prev.category,
      priority: req.body.priority ?? prev.priority,
      target_date: req.body.target_date !== undefined ? iso(req.body.target_date) : prev.target_date,
      success_metrics: req.body.success_metrics ?? prev.success_metrics,
      status: req.body.status ?? prev.status,
      updated_at: new Date().toISOString()
    };

    await run(
      `UPDATE goals SET
         title=?, description=?, category=?, priority=?, target_date=?, success_metrics=?, status=?, updated_at=?
       WHERE id=?`,
       [patch.title, patch.description, patch.category, patch.priority,
        patch.target_date, patch.success_metrics, patch.status,
        patch.updated_at, id]
    );
    res.json(await get(`SELECT * FROM goals WHERE id=?`, [id]));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete("/api/goals/:id", async (req, res) => {
  try {
    const result = await run(`DELETE FROM goals WHERE id=?`, [req.params.id]);
    res.json({ deleted: result.changes > 0 });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ------------- HABITS -------------
app.get("/api/habits", async (_req, res) => {
  try { res.json(await all(`SELECT * FROM habits ORDER BY created_at DESC`)); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

app.post("/api/habits", async (req, res) => {
  try {
    const { name, description, frequency, difficulty, preferred_time, status } = req.body;
    if (!name) return res.status(400).json({ error: "name required" });
    const now = new Date().toISOString();
    const result = await run(
      `INSERT INTO habits (name, description, frequency, difficulty, preferred_time, status, created_at, updated_at)
       VALUES (?,?,?,?,?,?,?,?)`,
      [name || "", description || "", frequency || "", difficulty || "",
       preferred_time || "", status || "active", now, now]
    );
    res.status(201).json(await get(`SELECT * FROM habits WHERE id=?`, [result.id]));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put("/api/habits/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const prev = await get(`SELECT * FROM habits WHERE id=?`, [id]);
    if (!prev) return res.status(404).json({ error: "Not found" });

    const patch = {
      name: req.body.name ?? prev.name,
      description: req.body.description ?? prev.description,
      frequency: req.body.frequency ?? prev.frequency,
      difficulty: req.body.difficulty ?? prev.difficulty,
      preferred_time: req.body.preferred_time ?? prev.preferred_time,
      status: req.body.status ?? prev.status,
      updated_at: new Date().toISOString()
    };

    await run(
      `UPDATE habits SET
        name=?, description=?, frequency=?, difficulty=?, preferred_time=?, status=?, updated_at=?
       WHERE id=?`,
      [patch.name, patch.description, patch.frequency, patch.difficulty,
       patch.preferred_time, patch.status, patch.updated_at, id]
    );
    res.json(await get(`SELECT * FROM habits WHERE id=?`, [id]));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete("/api/habits/:id", async (req, res) => {
  try {
    const result = await run(`DELETE FROM habits WHERE id=?`, [req.params.id]);
    res.json({ deleted: result.changes > 0 });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ------------- JOURNAL -------------
app.get("/api/journal", async (_req, res) => {
  try { res.json(await all(`SELECT * FROM journal ORDER BY date DESC, created_at DESC`)); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

app.post("/api/journal", async (req, res) => {
  try {
    const { mood, text, date } = req.body;
    const now = new Date().toISOString();
    const result = await run(
      `INSERT INTO journal (mood, text, date, created_at, updated_at)
       VALUES (?,?,?,?,?)`,
      [mood || "", text || "", iso(date) || now, now, now]
    );
    res.status(201).json(await get(`SELECT * FROM journal WHERE id=?`, [result.id]));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put("/api/journal/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const prev = await get(`SELECT * FROM journal WHERE id=?`, [id]);
    if (!prev) return res.status(404).json({ error: "Not found" });

    const patch = {
      mood: req.body.mood ?? prev.mood,
      text: req.body.text ?? prev.text,
      date: req.body.date !== undefined ? iso(req.body.date) : prev.date,
      updated_at: new Date().toISOString()
    };

    await run(
      `UPDATE journal SET mood=?, text=?, date=?, updated_at=? WHERE id=?`,
      [patch.mood, patch.text, patch.date, patch.updated_at, id]
    );
    res.json(await get(`SELECT * FROM journal WHERE id=?`, [id]));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete("/api/journal/:id", async (req, res) => {
  try {
    const result = await run(`DELETE FROM journal WHERE id=?`, [req.params.id]);
    res.json({ deleted: result.changes > 0 });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Fallback to SPA
app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/index.html"));
});

initDb().then(() => {
  const preferred = process.env.PORT ? Number(process.env.PORT) : 0; // 0 = any free port
  const server = app.listen(preferred, () => {
    const addr = server.address();
    const port = typeof addr === 'string' ? addr : addr.port;
    console.log(`🚀 Server running at http://localhost:${port}`);
  });
}).catch(err => {
  console.error("Failed to init DB", err);
  process.exit(1);
});
